

import os
import importlib


PLUGIN_DIR="/opt/wf/plugins"



def plugins():


    result=[]


    for f in os.listdir(PLUGIN_DIR):

        if f.endswith(".py"):

            result.append(
            f[:-3]
            )


    return result




def execute(name,target=None):


    mod=importlib.import_module(
    "plugins."+name
    )


    if target:

        return mod.run(target)


    return mod.run()



