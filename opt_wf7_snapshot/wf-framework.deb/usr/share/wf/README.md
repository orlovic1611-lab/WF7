# WF

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Commands

```bash
./scripts/install/wf show-config
./scripts/install/wf healthcheck --root .
./scripts/install/wf cleanup --root .
./scripts/install/wf run --audit logs/audit/main.json
./scripts/install/wf monitor --root . --audit logs/audit/main.json --interval 2
./scripts/install/wf report --audit logs/audit/main.json --out outputs/report.txt
```

## Notes

- `cleanup` reports cache and temporary artifacts without deleting them.
- `monitor` deduplicates repeated alerts before writing them to the audit file.
- `report` writes a short summary first and then appends CSV rows with a header.

## Output

- Audit data is written to `logs/audit/main.json`.
- Reports are written to `outputs/report.txt`.
