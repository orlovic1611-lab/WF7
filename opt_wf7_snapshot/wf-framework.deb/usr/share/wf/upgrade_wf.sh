#!/bin/bash
set -e

echo "[WF] Upgrading Watchdog Framework..."

mkdir -p \
src/wf/ai \
src/wf/ui \
src/wf/threats \
configs \
systemd \
logs/alerts \
outputs/dashboard


# VERSION
cat > src/wf/version.py <<'PY'
__version__ = "0.2.0"
__name__ = "WF Security Agent"
PY


# identity
cat > src/wf/identity.py <<'PY'
from .version import __version__, __name__

def banner():
    return f"""
================================
 {__name__}
 Version: {__version__}
 Host Monitoring Agent
================================
"""
PY


# AI guard placeholder
cat > src/wf/ai/guard.py <<'PY'
class AIGuard:

    def analyze(self, events):
        result=[]

        for e in events:
            if getattr(e,"severity",None) == "high":
                result.append(
                    {
                    "action":"alert",
                    "reason":"high severity event"
                    }
                )

        return result
PY


# threat rules
cat > src/wf/threats/rules.yaml <<'YAML'
rules:

  suspicious_process:
    severity: medium

  interface_down:
    severity: low

  repeated_event:
    severity: high

  unknown_binary:
    severity: high
YAML


# extended config
cat > configs/security.yaml <<'YAML'
name: WF Security Agent

version: 0.2.0

mode: defensive

monitor:
  filesystem: true
  processes: true
  network: true
  wifi: true

ai_guard:
  enabled: true

alerts:
  enabled: true

storage:
  audit: logs/audit/main.json
  reports: outputs/reports

YAML


# systemd service
cat > systemd/wf-agent.service <<'SERVICE'
[Unit]
Description=WF Security Agent
After=network.target


[Service]
Type=simple

WorkingDirectory=/opt/WF

ExecStart=/opt/WF/scripts/install/wf monitor --root /opt/WF --audit /opt/WF/logs/audit/main.json --interval 10

Restart=always
RestartSec=5


[Install]
WantedBy=multi-user.target
SERVICE


# CLI info command
cat > wf_info.py <<'PY'
from src.wf.identity import banner

print(banner())
PY


# package init
cat > src/wf/ai/__init__.py <<'PY'
PY

cat > src/wf/threats/__init__.py <<'PY'
PY


# reinstall
find . -name "__pycache__" -type d -exec rm -rf {} +

python -m pip install -e .


chmod +x scripts/install/wf


echo
echo "[WF] DONE"
echo
python wf_info.py

echo
echo "Next:"
echo "sudo cp -r . /opt/WF"
echo "sudo cp systemd/wf-agent.service /etc/systemd/system/"
echo "sudo systemctl daemon-reload"
echo "sudo systemctl enable wf-agent"
echo "sudo systemctl start wf-agent"

