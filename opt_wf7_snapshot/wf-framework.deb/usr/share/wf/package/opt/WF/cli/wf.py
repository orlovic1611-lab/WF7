#!/usr/bin/env python3

import sys
import os
import json

sys.path.insert(
    0,
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)


from config.settings import load
from modules.logger import write
from modules.plugin_manager import load_plugins


cfg=load()

write("WF CLI started")


if len(sys.argv)<2:

    print("""
WF SECURITY FRAMEWORK

Commands:

 wf info
 wf plugins
 wf logs

""")
    exit()



cmd=sys.argv[1]


if cmd=="info":

    print(json.dumps(cfg,indent=4))


elif cmd=="plugins":

    print(json.dumps(load_plugins(),indent=4))


elif cmd=="logs":

    try:
        print(open("logs/wf.log").read())
    except:
        print("No logs")


else:

    print("Unknown command")

