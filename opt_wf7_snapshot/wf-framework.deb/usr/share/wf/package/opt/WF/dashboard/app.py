
from fastapi import FastAPI,Request
from fastapi.templating import Jinja2Templates

from modules.system_info import run as system_info
from modules.scanner import run as scanner

from database.db import *

import json


init()


app=FastAPI(
title="WF Security Framework"
)


templates=Jinja2Templates(
directory="dashboard/templates"
)



@app.get("/")
def home(request:Request):

    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"request":request}
    )



@app.get("/api/system")
def system():

    return system_info()



@app.get("/api/scan/{target}")
def scan(target:str):

    result=scanner(target)

    add_scan(
        target,
        json.dumps(result)
    )

    return result



@app.get("/api/history")
def history():

    return {
        "history":get_scans()
    }


@app.get("/api/status")
def status():

    return {
        "status":"online",
        "framework":"WF v2"
    }


