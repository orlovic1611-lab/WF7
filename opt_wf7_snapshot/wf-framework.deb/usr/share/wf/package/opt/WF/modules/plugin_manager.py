
import os
import importlib


def load_plugins():

    result=[]


    if not os.path.exists("plugins"):
        return result


    for file in os.listdir("plugins"):

        if file.endswith(".py"):

            name=file[:-3]

            if name!="__init__":

                result.append(name)


    return result


