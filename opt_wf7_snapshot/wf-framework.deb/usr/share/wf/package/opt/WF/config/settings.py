
import os
import json


CONFIG="/etc/wf/config.json"


DEFAULT={

"name":"WF Security Framework",

"version":"2.0",

"log":"enabled",

"plugins":True

}


def load():

    if os.path.exists(CONFIG):

        with open(CONFIG) as f:
            return json.load(f)


    return DEFAULT


