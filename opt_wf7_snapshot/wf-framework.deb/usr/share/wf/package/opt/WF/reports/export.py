import json
from datetime import datetime


def save(data):

    name="reports/wf_report_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".json"

    with open(name,"w") as f:
        json.dump(data,f,indent=4)

    return name

