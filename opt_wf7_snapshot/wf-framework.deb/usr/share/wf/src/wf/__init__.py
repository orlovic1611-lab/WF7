"""WF defensive monitoring system."""
