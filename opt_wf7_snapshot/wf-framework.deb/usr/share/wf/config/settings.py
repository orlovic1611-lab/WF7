
VERSION="5.0"

NAME="WF Security Framework"

DASHBOARD="http://localhost:8080"


