#!/bin/bash

set -e

cd ~/termux/WF

echo "[WF] Creating professional dashboard..."

mkdir -p dashboard/templates
mkdir -p dashboard/static


cat > requirements-dashboard.txt <<'REQ'
fastapi
uvicorn
jinja2
REQ


cat > dashboard/app.py <<'PY'
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
import json
import psutil
from datetime import datetime


app = FastAPI(
    title="WF Security Dashboard",
    version="1.0"
)


BASE = Path("/opt/WF")

AUDIT = BASE / "logs/audit/main.json"


templates = Jinja2Templates(
    directory="dashboard/templates"
)



def load_events():

    if not AUDIT.exists():
        return []

    try:
        with open(AUDIT) as f:
            return json.load(f)

    except:
        return []



@app.get("/", response_class=HTMLResponse)
def home(request:Request):

    return templates.TemplateResponse(
        "index.html",
        {
            "request":request
        }
    )



@app.get("/api/status")
def status():

    events = load_events()


    severity={}

    for e in events:

        s=e.get(
            "severity",
            "unknown"
        )

        severity[s]=severity.get(s,0)+1


    return {

        "agent":"ONLINE",

        "time":
        str(datetime.now()),


        "events":
        len(events),


        "severity":
        severity,


        "cpu":
        psutil.cpu_percent(),


        "ram":
        psutil.virtual_memory().percent


    }




@app.get("/api/events")
def api_events():

    return JSONResponse(
        load_events()[-20:]
    )

PY



cat > dashboard/templates/index.html <<'HTML'
<!DOCTYPE html>

<html>

<head>

<title>
WF Security Dashboard
</title>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


<style>

body{

background:#080b10;
color:#eee;
font-family:Arial;
margin:0;

}


header{

background:#111827;
padding:25px;
font-size:28px;
color:#38bdf8;

}


.grid{

display:grid;
grid-template-columns:
repeat(auto-fit,minmax(250px,1fr));

gap:20px;
padding:20px;

}



.card{

background:#111827;
padding:20px;
border-radius:15px;

box-shadow:
0 0 20px #000;

}



.value{

font-size:40px;
color:#22c55e;

}


.alert{

color:#ef4444;

}


table{

width:100%;

}



td{

padding:8px;

border-bottom:
1px solid #333;

}


</style>


</head>



<body>



<header>

⚡ WF Security Agent Dashboard

</header>



<div class="grid">



<div class="card">

<h3>Status</h3>

<div class="value"
id="status">

-

</div>

</div>



<div class="card">

<h3>Events</h3>

<div class="value"
id="events">

-

</div>

</div>



<div class="card">

<h3>CPU</h3>

<div class="value"
id="cpu">

-

</div>

</div>



<div class="card">

<h3>RAM</h3>

<div class="value"
id="ram">

-

</div>

</div>



</div>




<div class="grid">


<div class="card">

<h2>
Threat levels
</h2>

<canvas id="chart"></canvas>


</div>



<div class="card">

<h2>
Recent events
</h2>


<table id="eventsTable">

</table>


</div>



</div>




<script>


let chart;



async function update(){


let s =
await fetch('/api/status')
.then(r=>r.json());



document
.getElementById("status")
.innerHTML=s.agent;


document
.getElementById("events")
.innerHTML=s.events;


document
.getElementById("cpu")
.innerHTML=s.cpu+"%";


document
.getElementById("ram")
.innerHTML=s.ram+"%";




if(chart)
chart.destroy();



chart=new Chart(
document
.getElementById("chart"),

{

type:"doughnut",

data:{

labels:
Object.keys(s.severity),

datasets:[{

data:
Object.values(s.severity)

}]

}

}

);





let ev=

await fetch('/api/events')
.then(r=>r.json());



let html="";


ev.reverse()
.forEach(e=>{


html+=`

<tr>

<td>
${e.source}
</td>

<td>
${e.kind}
</td>

<td>
${e.severity}
</td>

</tr>


`;


});


document
.getElementById("eventsTable")
.innerHTML=html;



}



update();


setInterval(
update,
5000
);



</script>


</body>

</html>
HTML





cat > /usr/local/bin/wf-dashboard <<'CMD'
#!/bin/bash

cd /opt/WF

uvicorn dashboard.app:app \
--host 0.0.0.0 \
--port 8080
CMD



chmod +x /usr/local/bin/wf-dashboard



pip install -r requirements-dashboard.txt



cat > /etc/systemd/system/wf-dashboard.service <<SERVICE
[Unit]

Description=WF Security Dashboard


After=network.target



[Service]

WorkingDirectory=/opt/WF

ExecStart=/opt/WF/.venv/bin/python -m uvicorn dashboard.app:app --host 0.0.0.0 --port 8080


Restart=always



[Install]

WantedBy=multi-user.target

SERVICE



systemctl daemon-reload

systemctl enable wf-dashboard

systemctl restart wf-dashboard



echo

echo "=============================="

echo " WF DASHBOARD READY "

echo " Open browser:"

echo " http://localhost:8080"

echo "=============================="

