#!/bin/bash

set -e

cd ~/termux/WF


echo "[WF] EXTREME UPGRADE"


mkdir -p src/wf/db
mkdir -p /opt/WF


cat > src/wf/db/database.py <<'PY'
from pathlib import Path
import sqlite3
import json
from datetime import datetime


DB=Path("data/wf.db")


def init_db():

    DB.parent.mkdir(exist_ok=True)

    con=sqlite3.connect(DB)

    con.execute("""
    CREATE TABLE IF NOT EXISTS events(
    id INTEGER PRIMARY KEY,
    time TEXT,
    source TEXT,
    kind TEXT,
    severity TEXT,
    details TEXT
    )
    """)

    con.commit()
    con.close()



def add_event(e):

    con=sqlite3.connect(DB)

    con.execute(
    """
    INSERT INTO events
    VALUES(NULL,?,?,?,?,?)
    """,
    (
    str(datetime.now()),
    e.get("source"),
    e.get("kind"),
    e.get("severity"),
    json.dumps(e.get("details"))
    ))

    con.commit()
    con.close()



def count():

    con=sqlite3.connect(DB)

    r=con.execute(
    "select count(*) from events"
    ).fetchone()

    con.close()

    return r[0]

PY



cat > src/wf/info.py <<'PY'

VERSION="1.0.0"

BANNER="""

================================
 WF Security Agent
 Version: 1.0.0

 Host Monitoring Framework
 Kali Linux Edition

================================

"""

def show():

    print(BANNER)

PY



cat > /usr/local/bin/wf <<'SH'
#!/bin/bash

cd /opt/WF

source .venv/bin/activate

python -m wf.cli.main "$@"

SH


chmod +x /usr/local/bin/wf


python -m pip install -e .


find . -name "__pycache__" -type d -exec rm -rf {} +


echo
echo "[WF] READY"
echo

wf show-config


