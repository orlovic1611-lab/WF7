import sqlite3
from datetime import datetime


DB="database/wf.db"


def connect():

    return sqlite3.connect(DB)



def init():

    con=connect()

    cur=con.cursor()


    cur.execute("""
    CREATE TABLE IF NOT EXISTS scans(

        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target TEXT,
        result TEXT,
        created TEXT

    )
    """)


    con.commit()
    con.close()



def add_scan(target,result):

    con=connect()

    cur=con.cursor()


    cur.execute(
    """
    INSERT INTO scans
    (target,result,created)

    VALUES (?,?,?)
    """,
    (
        target,
        result,
        datetime.now().isoformat()
    )
    )


    con.commit()
    con.close()



def get_scans():

    con=connect()

    cur=con.cursor()


    cur.execute(
        "SELECT * FROM scans ORDER BY id DESC"
    )


    data=cur.fetchall()

    con.close()


    return data

