
import socket


NAME="network"


def run():

    host=socket.gethostname()

    ip=socket.gethostbyname(host)


    return {

        "hostname":host,

        "ip":ip

    }

