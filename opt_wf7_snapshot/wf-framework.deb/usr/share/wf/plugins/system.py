
import platform
import os


NAME="system"


def run():

    return {

        "hostname":platform.node(),

        "os":platform.system(),

        "kernel":platform.release(),

        "cpu":os.cpu_count()

    }

