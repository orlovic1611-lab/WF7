
import subprocess


NAME="ports"


def run():

    try:

        result=subprocess.getoutput(
        "ss -tulnp"
        )

        return {
        "ports":result
        }


    except Exception as e:

        return {
        "error":str(e)
        }

