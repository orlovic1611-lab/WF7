from src.wf.identity import banner

print(banner())
