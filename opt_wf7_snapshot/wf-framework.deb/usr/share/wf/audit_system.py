import os
import ast
import sys

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))

print("=" * 80)
print(f"🔍 SPUŠŤAM UKÁZKOVÝ AUDIT PROJEKTU: {PROJECT_ROOT}")
print("=" * 80)

def audit_file(filepath):
    rel_path = os.path.relpath(filepath, PROJECT_ROOT)
    print(f"\n📄 Súbor: [ {rel_path} ]")
    
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    
    # 1. Kontrola syntaxe
    try:
        ast.parse(content)
        print("  🟢 Syntax: OK")
    except SyntaxError as se:
        print(f"  🔴 SYNTAX ERROR: Riadok {se.lineno}: {se.msg}")
        return

    # 2. Kontrola logiky a ciest
    lines = content.split('\n')
    hardcoded_paths = []
    suspicious_logic = []
    
    for idx, line in enumerate(lines, 1):
        # Kontrola ciest
        if "pcap" in line.lower() or "txt" in line.lower() or "log" in line.lower():
            if "/" in line and not line.strip().startswith("#"):
                hardcoded_paths.append((idx, line.strip()))
        
        # Kontrola logických chýb (prázdne except bloky, TODO, FIXME)
        if "except:" in line.replace(" ", ""):
            suspicious_logic.append((idx, "Prázdny 'except:' blok (môže maskovať pády systému)"))
        if "todo" in line.lower() or "fixme" in line.lower():
            suspicious_logic.append((idx, f"Nedokončená úloha: {line.strip()}"))

    if hardcoded_paths:
        print("  🟡 Nájdené cesty / súbory (Skontroluj správnosť):")
        for line_no, text in hardcoded_paths:
            print(f"     • Riadok {line_no}: {text}")
    else:
        print("  🟢 Cesty: Žiadne podozrivé fixné linky")

    if suspicious_logic:
        print("  ⚠️ Logické upozornenia:")
        for line_no, text in suspicious_logic:
            print(f"     • Riadok {line_no}: {text}")

# Prechod všetkými zložkami a podzložkami
python_files_found = False
for root, dirs, files in os.walk(PROJECT_ROOT):
    # Vynecháme venv a cache, tie nechceme kontrolovať
    if 'venv' in root or '__pycache__' in root or '.git' in root:
        continue
        
    for file in files:
        if file.endswith('.py') and file != 'audit_system.py':
            python_files_found = True
            audit_file(os.path.join(root, file))

if not python_files_found:
    print("❌ V tomto priečinku sa nenašli žiadne Python skripty na analýzu.")
print("\n" + "=" * 80)
print("🏁 AUDIT DOKONČENÝ. Skopíruj celý výstup a ideme upratovať!")
print("=" * 80)
