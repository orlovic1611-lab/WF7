import sys
import os
from datetime import datetime
from scapy.all import sniff, UDP, TCP, ARP, DNS, IP
from rich.console import Console
from rich.table import Table
from rich.live import Live
from rich.layout import Layout
from rich.panel import Panel

console = Console()

# Globálne počítadlá pre extra live štatistiky
stats = {"safe": 0, "warning": 0, "critical": 0, "total": 0, "ssdp_count": 0}
captured_rows = []
MAX_ROWS = 15  # Koľko riadkov histórie chceme držať na obrazovke

def process_packet(pkt):
    stats["total"] += 1
    
    # Získanie času
    time_str = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    
    # Predvolené sieťové identity
    src = pkt.src if hasattr(pkt, 'src') else "N/A"
    dst = pkt.dst if hasattr(pkt, 'dst') else "N/A"
    proto = "LAYER2"
    activity = "Štandardný linkový rámec"
    risk = "[bold green]BEZPEČNÉ[/bold green]"
    action = "Ignorovať"
    row_style = "default"

    # 1. IP Vrstva
    if pkt.haslayer(IP):
        src = pkt[IP].src
        dst = pkt[IP].dst
        proto = "IP"

        # UDP Protokol
        if pkt.haslayer(UDP):
            sport = pkt[UDP].sport
            dport = pkt[UDP].dport
            proto = f"UDP {sport}→{dport}"
            
            # Anomália: IoT Flooding
            if dport == 8001 or sport == 8001 or dport == 15600:
                activity = f"IoT Beacon / Šum na porte {dport}"
                risk = "[bold yellow]NÍZKA[/bold yellow]"
                action = "Monitorovať"
                row_style = "yellow"
                stats["warning"] += 1
            
            # Anomália: SSDP Spam
            elif dport == 1900 or dst == "239.255.255.250":
                proto = "SSDP"
                stats["ssdp_count"] += 1
                activity = f"SSDP Discovery Spam (#{stats['ssdp_count']})"
                risk = "[bold yellow]STREDNÁ[/bold yellow]"
                action = "Rate-Limit UPnP"
                row_style = "dark_orange"
                stats["warning"] += 1
            else:
                stats["safe"] += 1

        # TCP Protokol
        elif pkt.haslayer(TCP):
            sport = pkt[TCP].sport
            dport = pkt[TCP].dport
            proto = f"TCP {sport}→{dport}"
            
            # Kontrola neštandardných portov (Možný sken/útok)
            if dport not in [80, 443, 22, 53] and sport not in [80, 443, 22, 53]:
                activity = "Komunikácia na neštandardnom TCP porte"
                risk = "[bold red]KRITICKÁ[/bold red]"
                action = "BLOKOVAŤ / Preveriť port"
                row_style = "bold red"
                stats["critical"] += 1
            else:
                activity = "Udržiavanie relácie / Web traffic"
                row_style = "dim"
                stats["safe"] += 1

        # DNS Protokol
        if pkt.haslayer(DNS) and pkt[DNS].qr == 0:
            proto = "DNS Qry"
            try:
                qname = pkt[DNS].qd.qname.decode('utf-8', errors='ignore')
                activity = f"DNS Dopyt: {qname}"
                if "mozilla" in qname or "telemetry" in qname:
                    row_style = "purple"
                    action = "Logovať Telemetriu"
            except:
                activity = "DNS Dopyt (Neznámy host)"
            stats["safe"] += 1

    # 2. ARP Vrstva
    elif pkt.haslayer(ARP):
        proto = "ARP"
        if pkt[ARP].op == 1:
            activity = f"Who has {pkt[ARP].pdst}? Tell {pkt[ARP].psrc}"
            row_style = "bold cyan"
            action = "Nový Host v sieti"
        stats["safe"] += 1

    # 3. STP Vrstva
    elif "STP" in str(pkt.summary()) or (hasattr(pkt, 'type') and pkt.type == 0x0026):
        proto = "STP"
        activity = "Switch Spanning Tree Heartbeat"
        row_style = "blue"
        stats["safe"] += 1
    else:
        stats["safe"] += 1

    # Pridanie do lokálnej pamäte riadkov
    captured_rows.append((time_str, src, proto, activity, risk, action, row_style))
    if len(captured_rows) > MAX_ROWS:
        captured_rows.pop(0)

def generate_dashboard():
    stats_text = (
        f"[bold white]Celkovo paketov:[/bold white] {stats['total']}  │  "
        f"[bold green]Bezpečné:[/bold green] {stats['safe']}  │  "
        f"[bold yellow]Varovania (Anomálie):[/bold yellow] {stats['warning']}  │  "
        f"[bold red]Kritické hrozby:[/bold red] {stats['critical']}"
    )
    top_panel = Panel(stats_text, title="🛡️ LIVE ŠTATISTIKY SYSTÉMU", style="bold white on black")
    
    table = Table(expand=True)
    table.add_column("Čas", justify="center", style="cyan", no_wrap=True)
    table.add_column("Zdrojová adresa", justify="left", style="white", no_wrap=True)
    table.add_column("Protokol / Port", justify="left", no_wrap=True)
    table.add_column("Detegovaná aktivita / Stav anomálie", justify="left")
    table.add_column("Úroveň rizika", justify="center")
    table.add_column("Akcia IDS", justify="left")

    for row in captured_rows:
        table.add_row(row[0], row[1], row[2], row[3], row[4], row[5], style=row[6])
        
    layout = Layout()
    layout.split_column(Layout(top_panel, size=3), Layout(table))
    return layout

if __name__ == "__main__":
    if os.getuid() != 0:
        console.print("[bold red]Chyba: Živé skenovanie vyžaduje oprávnenia root (sudo)![/bold red]")
        console.print("[yellow]Spusti príkaz takto: sudo ./venv/bin/python3 live_ids.py[/yellow]")
        sys.exit(1)

    interface = "wlp1s0"  # Tvoja Wi-Fi karta
    console.print(f"[bold green]Spúšťam reálny IDS skener na rozhraní {interface}...[/bold green]")

    try:
        with Live(generate_dashboard(), refresh_per_second=4, screen=True) as live:
            sniff(iface=interface, prn=lambda p: [process_packet(p), live.update(generate_dashboard())], store=0)
    except KeyboardInterrupt:
        console.print("\n[bold red]Skenovanie zastavené používateľom.[/bold red]")
